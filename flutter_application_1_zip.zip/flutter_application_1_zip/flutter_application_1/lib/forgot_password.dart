import 'dart:math';
import 'package:flutter/material.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';


class ForgotPasswordPage extends StatefulWidget {
  final String email; // user email

  const ForgotPasswordPage({super.key, required this.email});

  @override
  _ForgotPasswordPageState createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final TextEditingController otpController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  int? generatedOTP;
  bool otpSent = false;
  bool otpVerified = false;

  // ✅ Function to send OTP via email
  Future<void> sendOTP(String email) async {
    final random = Random();
    generatedOTP = 1000 + random.nextInt(9000); // 4-digit OTP

    String username = "yourgmail@gmail.com"; // <-- Replace with your Gmail
    String password = "your_app_password";    // <-- Replace with Gmail App Password

    final smtpServer = gmail(username, password);

    final message = Message()
      ..from = Address(username, "Employee App")
      ..recipients.add(email)
      ..subject = "Password Reset OTP"
      ..text = "Your OTP for password reset is: $generatedOTP";

    try {
      await send(message, smtpServer);
      setState(() {
        otpSent = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("OTP sent to your email ✅")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to send OTP ❌ $e")),
      );
    }
  }

  // ✅ Verify OTP
  void verifyOTP() {
    if (otpController.text == generatedOTP.toString()) {
      setState(() {
        otpVerified = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("OTP Verified 🎉")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Invalid OTP ❌")),
      );
    }
  }

  // ✅ Reset Password
  void resetPassword() {
    String newPass = newPasswordController.text.trim();
    if (newPass.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Password must be at least 6 characters")),
      );
      return;
    }

    // Here you should update the password in your database / users map
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Password reset successful ✅")),
    );

    Navigator.pop(context); // Go back to login page
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Forgot Password")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            if (!otpSent) ...[
              Text("Send OTP to ${widget.email}",
                  style: const TextStyle(fontSize: 18)),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => sendOTP(widget.email),
                child: const Text("Send OTP"),
              ),
            ],
            if (otpSent && !otpVerified) ...[
              TextField(
                controller: otpController,
                decoration: const InputDecoration(
                  labelText: "Enter OTP",
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: verifyOTP,
                child: const Text("Verify OTP"),
              ),
            ],
            if (otpVerified) ...[
              TextField(
                controller: newPasswordController,
                decoration: const InputDecoration(
                  labelText: "Enter New Password",
                  border: OutlineInputBorder(),
                ),
                obscureText: true,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: resetPassword,
                child: const Text("Reset Password"),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
