import 'package:flutter/material.dart';

class EmployeePreviewPage extends StatelessWidget {
  final Map<String, String> data;
  const EmployeePreviewPage({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final isSingle = data['Marital Status'] == 'Single';

    // Filter out keys that should not be displayed
    final filteredData = data.entries.where((entry) {
      final key = entry.key;
      final value = entry.value.trim();

      // Rule: Remove Spouse Name if the person is Single OR the value is empty
      if (key == 'Spouse Name' && (isSingle || value.isEmpty)) {
        return false;
      }

      // Rule: Optionally, remove any key with an empty value
      // if (value.isEmpty) {
      //   return false;
      // }

      return true;
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text("Employee Preview")),
      body: ListView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: filteredData.length,
        itemBuilder: (context, index) {
          final entry = filteredData[index];
          final key = entry.key;
          final value = entry.value;
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Text(
              "$key: ${value.isEmpty ? 'N/A' : value}",
              style: const TextStyle(fontSize: 16),
            ),
          );
        },
      ),
    );
  }
}
