import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'edit_employee_page.dart';
import 'main.dart'; // ✅ Import your login page

class ExistingEmployeePage extends StatefulWidget {
  const ExistingEmployeePage({super.key});

  @override
  State<ExistingEmployeePage> createState() => _ExistingEmployeePageState();
}

class _ExistingEmployeePageState extends State<ExistingEmployeePage> {
  List<Map<String, dynamic>> employees = [];
  bool loading = true;

  final String sheetUrl =
      "https://script.google.com/macros/s/AKfycbyAsRJ-wwaKOBl5UGipfoqgZhd1MUBcdCP8qD2JAnE_a2DP_BnwuC0B6ZdmQZQipAo_/exec";

  @override
  void initState() {
    super.initState();
    fetchEmployees();
  }

  Future<void> fetchEmployees() async {
    try {
      var client = http.Client();
      final request = http.Request('GET', Uri.parse(sheetUrl))
        ..headers.addAll({
          "Content-Type": "text/plain; charset=utf-8",
          "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          "Accept": "application/json",
        });

      final response = await client.send(request);
      final streamedResponse = await http.Response.fromStream(response);

      if (streamedResponse.statusCode == 200) {
        final result = jsonDecode(streamedResponse.body);
        final List<dynamic> data = result['data'] ?? [];

        for (int i = 0; i < data.length; i++) {
          if (data[i] is Map<String, dynamic>) {
            data[i]["rowIndex"] = i + 2;
          }
        }

        setState(() {
          employees = data.cast<Map<String, dynamic>>();
          loading = false;
        });
      } else {
        throw Exception("Failed to load data");
      }
      client.close();
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error fetching data: $e")));
    }
  }

  void openEditForm(Map<String, dynamic> employee) async {
    final String dynamicScriptId = employee["ID"]?.toString() ?? "ERROR_ID";

    final Map<String, dynamic>? updatedData = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            EditEmployeePage(employee: employee, scriptId: dynamicScriptId),
      ),
    );

    if (updatedData != null) {
      final indexToUpdate = employees.indexWhere(
        (e) => e["ID"] == employee["ID"],
      );

      if (indexToUpdate != -1) {
        setState(() {
          updatedData["rowIndex"] = employees[indexToUpdate]["rowIndex"];
          employees[indexToUpdate] = updatedData;
        });
      }

      await fetchEmployees();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Existing Employees 1"),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Image.asset(
              'assets/logo.png', // ✅ Your logo path
              height: 30,
              width: 30,
              errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.image_not_supported),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: () {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text("Logged out")));
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: employees.length,
              itemBuilder: (context, index) {
                final emp = employees[index];
                return Card(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  child: ListTile(
                    title: Text(emp["Full Name"] ?? "Unnamed"),
                    subtitle: Text("Department: ${emp["Department"] ?? "N/A"}"),
                    trailing: IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () => openEditForm(emp),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
