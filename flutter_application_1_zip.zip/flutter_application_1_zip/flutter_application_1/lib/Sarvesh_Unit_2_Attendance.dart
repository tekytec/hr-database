import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'main.dart'; // ✅ Import your login page

class SarveshUnit2AttendancePage extends StatefulWidget {
  const SarveshUnit2AttendancePage({super.key});

  @override
  State<SarveshUnit2AttendancePage> createState() => _SarveshUnit2AttendancePageState();
}

class _SarveshUnit2AttendancePageState extends State<SarveshUnit2AttendancePage> {
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final idController = TextEditingController();

  String attendanceStatus = "Present";
  String shiftType = "Full Day";

  final String sheetUrl = "https://script.google.com/macros/s/AKfycbyvOOU4ecvQSc4ocCv3CCelLoN0h_QLZKz5XmIUJsX2t180nx3rhAaRWIw2BY6psqP6/exec";

  Future<void> saveToSheet() async {
    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all required fields ❗")),
      );
      return;
    }

    final data = {
      "Name": nameController.text.trim(),
      "Employee ID": idController.text.trim(),
      "Status": attendanceStatus,
      "Shift": attendanceStatus == "Present" ? shiftType : "N/A",
      "Date": DateTime.now().toIso8601String().split("T").first,
    };

    try {
      final response = await http.post(
        Uri.parse(sheetUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(data),
      );

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);
        if (result["status"] == "success") {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("✅ Attendance saved successfully")),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("❌ Error: ${result["message"] ?? response.body}")),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ Failed (${response.statusCode}): ${response.body}")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Network error: $e")),
      );
    }
  }

  void downloadPDF() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("PDF download triggered 📄")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Attendance - Sarvesh Unit 2"),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Image.asset(
              'assets/logo.png', // ✅ Your logo path
              height: 30,
              width: 30,
              errorBuilder: (context, error, stackTrace) => const Icon(Icons.image_not_supported),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Logged out")),
              );
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              buildCard(
                icon: Icons.person,
                title: "Employee Details",
                child: Column(
                  children: [
                    buildTextField("Name", nameController),
                    const SizedBox(height: 10),
                    buildTextField("Employee ID", idController),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              buildCard(
                icon: Icons.check_circle,
                title: "Attendance Status",
                child: buildSegmentedControl(
                  ["Present", "Absent"],
                  attendanceStatus,
                  (val) => setState(() => attendanceStatus = val),
                ),
              ),
              const SizedBox(height: 16),
              if (attendanceStatus == "Present")
                buildCard(
                  icon: Icons.access_time,
                  title: "Shift Type",
                  child: buildSegmentedControl(
                    ["Full Day", "Half Day", "Kal Shift"],
                    shiftType,
                    (val) => setState(() => shiftType = val),
                  ),
                ),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.cloud_upload),
                    label: const Text("Save to Sheet"),
                    onPressed: saveToSheet,
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text("Download PDF"),
                    onPressed: downloadPDF,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildCard({required IconData icon, required String title, required Widget child}) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.blue),
                const SizedBox(width: 10),
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      validator: (val) => val == null || val.isEmpty ? "Enter $label" : null,
    );
  }

  Widget buildSegmentedControl(
    List<String> options,
    String selected,
    void Function(String) onChanged,
  ) {
    return Wrap(
      spacing: 10,
      children: options.map((option) {
        final isSelected = option == selected;
        return ChoiceChip(
          label: Text(option),
          selected: isSelected,
          onSelected: (_) => onChanged(option),
          selectedColor: Colors.blue.shade100,
          labelStyle: TextStyle(
            color: isSelected ? Colors.blue.shade900 : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        );
      }).toList(),
    );
  }
}