import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'employee_preview_page.dart';
import 'main.dart'; // ✅ Import your login page

class CheranPlasticsnewempPage extends StatefulWidget {
  const CheranPlasticsnewempPage({super.key});

  @override
  _CheranPlasticsnewempPageState createState() => _CheranPlasticsnewempPageState();
}

class _CheranPlasticsnewempPageState extends State<CheranPlasticsnewempPage> {
  final _formKey = GlobalKey<FormState>();

  final Map<String, TextEditingController> controllers = {
    "fullName": TextEditingController(),
    "spouseName": TextEditingController(),
    "dob": TextEditingController(),
    "bloodGroup": TextEditingController(),
    "fatherName": TextEditingController(),
    "motherName": TextEditingController(),
    "mobile": TextEditingController(),
    "emergencyContact": TextEditingController(),
    "apartment": TextEditingController(),
    "street": TextEditingController(),
    "city": TextEditingController(),
    "state": TextEditingController(),
    "pincode": TextEditingController(),
    "aadhar": TextEditingController(),
    "pan": TextEditingController(),
    "voter": TextEditingController(),
    "esi": TextEditingController(),
    "pfuan": TextEditingController(),
    "doj": TextEditingController(),
    "department": TextEditingController(),
    "employeeType": TextEditingController(),
    "bankName": TextEditingController(),
    "account": TextEditingController(),
    "ifsc": TextEditingController(),
    "branch": TextEditingController(),
  };

  String gender = "Male";
  String maritalStatus = "Single";

  PlatformFile? aadharFront;
  PlatformFile? aadharBack;
  PlatformFile? panCard;
  PlatformFile? employeePhoto;

  Future<void> pickFile(Function(PlatformFile) onPicked) async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result != null && result.files.isNotEmpty) {
      onPicked(result.files.first);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("New Employee - Cheran Plastics"),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Image.asset(
              'assets/logo.png',
              height: 30,
              width: 30,
              errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.image_not_supported),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Logged out")),
              );
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildSectionHeader("👤 Personal Details"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildTextField("Full Name (as per Aadhar)", controllers["fullName"]!),
                  buildDropdown("Gender", ["Male", "Female", "Other"], (val) => setState(() => gender = val!)),
                  buildDropdown("Marital Status", ["Single", "Married"], (val) => setState(() => maritalStatus = val!)),
                  buildTextField("Spouse Name", controllers["spouseName"]!),
                  buildTextField("Date of Birth", controllers["dob"]!),
                  buildTextField("Blood Group", controllers["bloodGroup"]!),
                  buildTextField("Father Name", controllers["fatherName"]!),
                  buildTextField("Mother Name", controllers["motherName"]!),
                  buildTextField("Mobile Number", controllers["mobile"]!),
                  buildTextField("Emergency Contact Number", controllers["emergencyContact"]!),
                ],
              ),
              const SizedBox(height: 30),
              buildSectionHeader("🏠 Address Details"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildTextField("Apartment No", controllers["apartment"]!),
                  buildTextField("Street Name", controllers["street"]!),
                  buildTextField("City", controllers["city"]!),
                  buildTextField("State", controllers["state"]!),
                  buildTextField("Pincode", controllers["pincode"]!),
                ],
              ),
              const SizedBox(height: 30),
              buildSectionHeader("🏦 Bank Details"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildTextField("Bank Name", controllers["bankName"]!),
                  buildTextField("Account Number", controllers["account"]!),
                  buildTextField("IFSC Code", controllers["ifsc"]!),
                  buildTextField("Branch", controllers["branch"]!),
                ],
              ),
              const SizedBox(height: 30),
              buildSectionHeader("📋 Other Details"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildTextField("Aadhar Number", controllers["aadhar"]!),
                  buildTextField("PAN Number", controllers["pan"]!),
                  buildTextField("Voter ID/Driving License", controllers["voter"]!),
                  buildTextField("ESI Number", controllers["esi"]!),
                  buildTextField("PF UAN Number", controllers["pfuan"]!),
                  buildTextField("Date of Joining", controllers["doj"]!),
                  buildTextField("Department", controllers["department"]!),
                  buildTextField("Employee Type", controllers["employeeType"]!),
                ],
              ),
              const SizedBox(height: 30),
              buildSectionHeader("📎 Upload Original Documents"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildFileUpload("Aadhar Front Side", aadharFront, (file) => setState(() => aadharFront = file)),
                  buildFileUpload("Aadhar Back Side", aadharBack, (file) => setState(() => aadharBack = file)),
                  buildFileUpload("PAN Card", panCard, (file) => setState(() => panCard = file)),
                  buildFileUpload("Employee Photo (Plain Background)", employeePhoto, (file) => setState(() => employeePhoto = file)),
                ],
              ),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.preview),
                    label: const Text("Preview Details"),
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => EmployeePreviewPage(
                              data: {
                                for (var entry in controllers.entries) entry.key: entry.value.text,
                                "Gender": gender,
                                "Marital Status": maritalStatus,
                              },
                            ),
                          ),
                        );
                      }
                    },
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.save),
                    label: const Text("Save to Google Sheet"),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Saving to Google Sheet...")),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller) {
    return SizedBox(
      width: 400,
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        validator: (value) => value == null || value.isEmpty ? "Enter $label" : null,
      ),
    );
  }

  Widget buildDropdown(String label, List<String> options, Function(String?) onChanged) {
    return SizedBox(
      width: 400,
      child: DropdownButtonFormField<String>(
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        items: options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget buildFileUpload(String label, PlatformFile? file, Function(PlatformFile) onPicked) {
    return SizedBox(
      width: 400,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          ElevatedButton.icon(
            icon: const Icon(Icons.upload_file),
            label: Text(file == null ? "Upload" : file.name),
            onPressed: () => pickFile(onPicked),
          ),
          if (file != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                "Selected: ${file.name}",
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ),
        ],
      ),
    );
  }
}