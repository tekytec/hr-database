import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'employee_preview_page.dart';
import 'main.dart'; // ✅ Import your login page

class SarveshUnit2NewEmpPage extends StatefulWidget {
  const SarveshUnit2NewEmpPage({super.key});

  @override
  _SarveshUnit2NewEmpPageState createState() => _SarveshUnit2NewEmpPageState();
}

class _SarveshUnit2NewEmpPageState extends State<SarveshUnit2NewEmpPage> {
  final _formKey = GlobalKey<FormState>();

  final Map<String, TextEditingController> controllers = {
    "fullName": TextEditingController(),
    "spouseName": TextEditingController(),
    "dob": TextEditingController(),
    "bloodGroup": TextEditingController(),
    "fatherName": TextEditingController(),
    "motherName": TextEditingController(),
    "mobile": TextEditingController(),
    "emergencyContact": TextEditingController(),
    "apartment": TextEditingController(),
    "street": TextEditingController(),
    "city": TextEditingController(),
    "state": TextEditingController(),
    "pincode": TextEditingController(),
    "aadhar": TextEditingController(),
    "pan": TextEditingController(),
    "voter": TextEditingController(),
    "esi": TextEditingController(),
    "pfuan": TextEditingController(),
    "doj": TextEditingController(),   // ✅ DOJ added
    "department": TextEditingController(),
    "employeeType": TextEditingController(),
    "bankName": TextEditingController(),
    "account": TextEditingController(),
    "ifsc": TextEditingController(),
    "branch": TextEditingController(),
  };

  String gender = "Male";
  String maritalStatus = "Single";

  PlatformFile? aadharFront;
  PlatformFile? aadharBack;
  PlatformFile? panCard;
  PlatformFile? employeePhoto;

  final String sheetUrl =
      "https://script.google.com/macros/s/AKfycbw6WIRz0GZg1nf1oWW6jIVb18Oc52WibrN6KHc82CS68hhslFHz5sTBlvqrIsJIEvA2Aw/exec";

  final appsScriptUploadUrl =
      "https://script.google.com/macros/s/AKfycbw_9jgUhJtZwRYtE_YGtRkc72r3shLjPQK-2DP7Xgw_lfBxKPdGmvH5pS5gaoRR1-ZalA/exec";

  Future<void> pickFile(Function(PlatformFile) onPicked) async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result != null && result.files.isNotEmpty) {
      onPicked(result.files.first);
    }
  }

  Future<String?> uploadFileToDrive(PlatformFile file) async {
    final client = http.Client();
    final bytes = file.bytes!;

    final payload = {
      'fileName': file.name,
      'mimeType': _mimeType(file.extension ?? ''),
      'base64': base64Encode(bytes),
    };

    try {
      final request = http.Request('POST', Uri.parse(appsScriptUploadUrl))
        ..headers.addAll({
          'Content-Type': 'text/plain',
          'Accept': 'application/json',
        })
        ..body = jsonEncode(payload);

      final streamedResponse = await client.send(request);
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);
        if (result['status'] == 'success') {
          client.close();
          print("Upload result: $result");
          return result['data']['url'];
        } else {
          print('Script Error: ${result['message']}');
          client.close();
          return null;
        }
      } else {
        print('HTTP Error: ${response.statusCode}');
        client.close();
        return null;
      }
    } catch (e) {
      print('Network Error: $e');
      client.close();
      return null;
    }
  }

  String _mimeType(String ext) {
    final e = ext.toLowerCase();
    return switch (e) {
      'jpg' || 'jpeg' => 'image/jpeg',
      'png' => 'image/png',
      'pdf' => 'application/pdf',
      _ => 'application/octet-stream',
    };
  }

  Future<String?> saveToSheet() async {
    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all required fields ❗")),
      );
      return null;
    }

    final Map<String, String> uploadUrls = {};

    final filesToUpload = {
      "Aadhar Front": aadharFront,
      "Aadhar Back": aadharBack,
      "PAN Card": panCard,
      "Employee Photo": employeePhoto,
    };

    for (var entry in filesToUpload.entries) {
      final file = entry.value;
      if (file != null) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text("Uploading ${entry.key}...")));
        final url = await uploadFileToDrive(file);
        uploadUrls[entry.key] = url ?? '';
      } else {
        uploadUrls[entry.key] = '';
      }
    }

    final data = {
      "Full Name": controllers["fullName"]!.text.trim(),
      "Gender": gender,
      "Marital Status": maritalStatus,
      "Spouse Name": controllers["spouseName"]!.text.trim(),
      "Date of Birth": controllers["dob"]!.text.trim(),
      "Blood Group": controllers["bloodGroup"]!.text.trim(),
      "Father Name": controllers["fatherName"]!.text.trim(),
      "Mother Name": controllers["motherName"]!.text.trim(),
      "Mobile Number": controllers["mobile"]!.text.trim(),
      "Emergency Contact": controllers["emergencyContact"]!.text.trim(),
      "Apartment No": controllers["apartment"]!.text.trim(),
      "Street Name": controllers["street"]!.text.trim(),
      "City": controllers["city"]!.text.trim(),
      "State": controllers["state"]!.text.trim(),
      "Pincode": controllers["pincode"]!.text.trim(),
      "Aadhar Number": controllers["aadhar"]!.text.trim(),
      "PAN Number": controllers["pan"]!.text.trim(),
      "Voter ID/Driving License": controllers["voter"]!.text.trim(),
      "ESI Number": controllers["esi"]!.text.trim(),
      "PF UAN Number": controllers["pfuan"]!.text.trim(),
      "Date of Joining": controllers["doj"]!.text.trim(),  // ✅ DOJ field added
      "Department": controllers["department"]!.text.trim(),
      "Employee Type": controllers["employeeType"]!.text.trim(),
      "Bank Name": controllers["bankName"]!.text.trim(),
      "Account Number": controllers["account"]!.text.trim(),
      "IFSC Code": controllers["ifsc"]!.text.trim(),
      "Branch": controllers["branch"]!.text.trim(),
      "Aadhar Front": uploadUrls["Aadhar Front"] ?? '',
      "Aadhar Back": uploadUrls["Aadhar Back"] ?? '',
      "PAN Card": uploadUrls["PAN Card"] ?? '',
      "Employee Photo": uploadUrls["Employee Photo"] ?? '',
    };

    try {
      var client = http.Client();
      final request = http.Request('POST', Uri.parse(sheetUrl))
        ..headers.addAll({
          "Content-Type": "text/plain; charset=utf-8",
          "Accept": "application/json",
        })
        ..body = jsonEncode(data);

      final response = await client.send(request);
      final streamedResponse = await http.Response.fromStream(response);

      if (streamedResponse.statusCode == 200) {
        final result = jsonDecode(streamedResponse.body);
        if (result["status"] == "success") {
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text("Saving to Google Sheet...")));

          controllers.forEach((__, c) => c.clear());
          setState(() {
            gender = "Male";
            maritalStatus = "Single";
            aadharFront = null;
            aadharBack = null;
            panCard = null;
            employeePhoto = null;
          });

          return result["data"]["ID"];
        } else {
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text("❌ Error: ${result["message"]}")));
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "❌ Failed (${streamedResponse.statusCode}): ${streamedResponse.body}",
            ),
          ),
        );
      }
      client.close();
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("❌ Network error: $e")));
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("New Employee - Sarvesh Unit 2"),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Image.asset(
              'assets/logo.png',
              height: 30,
              width: 30,
              errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.image_not_supported),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text("Logged out")));
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildSectionHeader("👤 Personal Details"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildTextField("Full Name (as per Aadhar)", controllers["fullName"]!),
                  buildDropdown("Gender", ["Male", "Female", "Other"],
                      (val) => setState(() => gender = val!)),
                  buildDropdown(
                    "Marital Status",
                    ["Single", "Married", "Other"],
                    (val) {
                      setState(() {
                        maritalStatus = val!;
                        if (maritalStatus == "Single") {
                          controllers["spouseName"]!.clear();
                        }
                      });
                    },
                    maritalStatus,
                  ),
                  if (maritalStatus == "Married")
                    buildTextField("Spouse Name", controllers["spouseName"]!),

                  buildDatePickerField("Date of Birth", controllers["dob"]!),  // ✅ DOB
                  buildTextField("Blood Group", controllers["bloodGroup"]!),
                  buildTextField("Father Name", controllers["fatherName"]!),
                  buildTextField("Mother Name", controllers["motherName"]!),
                  buildTextField("Mobile Number", controllers["mobile"]!),
                  buildTextField("Emergency Contact Number",
                      controllers["emergencyContact"]!),
                ],
              ),

              const SizedBox(height: 30),

              buildSectionHeader("🏠 Address Details"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildTextField("Apartment No", controllers["apartment"]!),
                  buildTextField("Street Name", controllers["street"]!),
                  buildTextField("City", controllers["city"]!),
                  buildTextField("State", controllers["state"]!),
                  buildTextField("Pincode", controllers["pincode"]!),
                ],
              ),

              const SizedBox(height: 30),

              buildSectionHeader("🏦 Bank Details"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildTextField("Bank Name", controllers["bankName"]!),
                  buildTextField("Account Number", controllers["account"]!),
                  buildTextField("IFSC Code", controllers["ifsc"]!),
                  buildTextField("Branch", controllers["branch"]!),
                ],
              ),

              const SizedBox(height: 30),

              buildSectionHeader("📋 Other Details"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildTextField("Aadhar Number", controllers["aadhar"]!),
                  buildTextField("PAN Number", controllers["pan"]!),
                  buildTextField("Voter ID/Driving License", controllers["voter"]!),
                  buildTextField("ESI Number", controllers["esi"]!),
                  buildTextField("PF UAN Number", controllers["pfuan"]!),

                  buildDatePickerField("Date of Joining", controllers["doj"]!),  // ✅ DOJ Added

                  buildTextField("Department", controllers["department"]!),
                  buildTextField("Employee Type", controllers["employeeType"]!),
                ],
              ),

              const SizedBox(height: 30),

              buildSectionHeader("📎 Upload Original Documents"),
              Wrap(
                spacing: 20,
                runSpacing: 20,
                children: [
                  buildFileUpload("Aadhar Front Side", aadharFront,
                      (file) => setState(() => aadharFront = file)),
                  buildFileUpload("Aadhar Back Side", aadharBack,
                      (file) => setState(() => aadharBack = file)),
                  buildFileUpload("PAN Card", panCard,
                      (file) => setState(() => panCard = file)),
                  buildFileUpload("Employee Photo (Plain Background)", employeePhoto,
                      (file) => setState(() => employeePhoto = file)),
                ],
              ),

              const SizedBox(height: 30),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.preview),
                    label: const Text("Preview Details"),
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => EmployeePreviewPage(
                              data: {
                                for (var entry in controllers.entries)
                                  entry.key: entry.value.text,
                                "Gender": gender,
                                "Marital Status": maritalStatus,
                              },
                            ),
                          ),
                        );
                      }
                    },
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.save),
                    label: const Text("Save to Google Sheet"),
                    onPressed: () async {
                      final newId = await saveToSheet();
                      if (newId != null) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                                "✅ Employee data saved successfully. ID: $newId"),
                          ),
                        );
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: const TextStyle(
            fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller) {
    return SizedBox(
      width: 400,
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        validator: (value) =>
            value == null || value.isEmpty ? "Enter $label" : null,
      ),
    );
  }

  Widget buildDropdown(
      String label, List<String> options, Function(String?) onChanged,
      [String? currentValue]) {
    return SizedBox(
      width: 400,
      child: DropdownButtonFormField<String>(
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        value: currentValue,
        items:
            options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget buildFileUpload(
      String label, PlatformFile? file, Function(PlatformFile) onPicked) {
    return SizedBox(
      width: 400,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          ElevatedButton.icon(
            icon: const Icon(Icons.upload_file),
            label: Text(file == null ? "Upload" : file.name),
            onPressed: () => pickFile(onPicked),
          ),
          if (file != null)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text("Selected: ${file.name}",
                  style: const TextStyle(fontSize: 12, color: Colors.grey)),
            ),
        ],
      ),
    );
  }

  Widget buildDatePickerField(
      String label, TextEditingController controller) {
    return SizedBox(
      width: 400,
      child: TextFormField(
        controller: controller,
        readOnly: true,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          suffixIcon: const Icon(Icons.calendar_today),
        ),
        validator: (value) =>
            value == null || value.isEmpty ? "Select $label" : null,
        onTap: () async {
          FocusScope.of(context).requestFocus(FocusNode());
          final DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime(1990),
            lastDate: DateTime.now().add(const Duration(days: 365)),
          );
          if (pickedDate != null) {
            controller.text =
                "${pickedDate.day.toString().padLeft(2, '0')}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.year}";
          }
        },
      ),
    );
  }
}
