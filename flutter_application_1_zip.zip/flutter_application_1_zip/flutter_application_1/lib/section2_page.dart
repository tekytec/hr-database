import 'package:flutter/material.dart';
import 'package:flutter_application_1/Sarvesh_Unit_2_Existing_Emp.dart';
import 'sarvesh_unit_2_new_emp.dart';
//import 'sarvesh_Unit_2_Attendance.dart';
import 'main.dart'; // ✅ Import login page

class Section2Page extends StatelessWidget {
  final String userEmail;

  const Section2Page({super.key, required this.userEmail});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sarvesh Unit 2"),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Image.asset(
              'assets/logo.png', // ✅ Your logo path
              height: 30,
              width: 30,
              errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.image_not_supported),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: () {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text("Logged out")));
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildDashboardTile(
            context,
            title: "Employee Management",
            subtitle: "Add new employees and manage records",
            icon: Icons.person_add,
            color: Colors.blue,
            page:
                SarveshUnit2NewEmpPage(), // ✅ You can pass userEmail if needed
          ),
          _buildDashboardTile(
            context,
            title: "Existing Employee",
            subtitle: "View and edit existing employee data",
            icon: Icons.people,
            color: Colors.green,
            page: const ExistingEmployeePage(),
          ),
       //   _buildDashboardTile(
       //      context,
       //      title: "Attendance",
       //      subtitle: "Mark and track daily attendance",
       //      icon: Icons.check_circle,
       //      color: Colors.orange,
       //      page: const SarveshUnit2AttendancePage(),
       //    ),
        ],
      ),
    );
  }

  Widget _buildDashboardTile(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required Widget page,
  }) {
    return GestureDetector(
      onTap: () =>
          Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border(left: BorderSide(color: color, width: 5)),
        ),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: color,
            child: Icon(icon, color: Colors.white),
          ),
          title: Text(
            title,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        ),
      ),
    );
  }
}

class PlaceholderPage extends StatelessWidget {
  final String title;
  const PlaceholderPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: Text(
          "$title Page (Coming Soon)",
          style: const TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
