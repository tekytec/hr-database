import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class EditEmployeePage extends StatefulWidget {
  final Map<String, dynamic> employee;
  final String scriptId;

  const EditEmployeePage({
    super.key,
    required this.employee,
    required this.scriptId,
  });

  @override
  State<EditEmployeePage> createState() => _EditEmployeePageState();
}

class _EditEmployeePageState extends State<EditEmployeePage> {
  final _formKey = GlobalKey<FormState>();
  late Map<String, TextEditingController> controllers;
  String maritalStatus = "";

  static const String scriptBaseUrl =
      "https://script.google.com/macros/s/AKfycbyAsRJ-wwaKOBl5UGipfoqgZhd1MUBcdCP8qD2JAnE_a2DP_BnwuC0B6ZdmQZQipAo_/exec";

  late final String scriptUrl;

  @override
  void initState() {
    super.initState();
    scriptUrl = "$scriptBaseUrl?id=${widget.scriptId}&method=PUT";

    maritalStatus = widget.employee["Marital Status"]?.toString() ?? "Single";

    controllers = {
      for (var key in widget.employee.keys)
        if (key != "rowIndex")
          key: TextEditingController(
            text: widget.employee[key]?.toString() ?? "",
          ),
    };

    if (!controllers.containsKey("Spouse Name")) {
      controllers["Spouse Name"] = TextEditingController();
    }
  }

  @override
  void dispose() {
    for (var controller in controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> updateEmployee() async {
    if (_formKey.currentState!.validate()) {
      final updatedData = {
        for (var entry in controllers.entries)
          if (entry.key != "Marital Status" && entry.key != "Spouse Name")
            entry.key: entry.value.text,
        "rowIndex": widget.employee["rowIndex"],
        "Marital Status": maritalStatus,
        "Spouse Name": maritalStatus == "Married"
            ? controllers["Spouse Name"]?.text ?? ""
            : "N/A",
      };
      var client = http.Client();
      final request = http.Request('POST', Uri.parse(scriptUrl))
        ..headers.addAll({
          "Content-Type": "text/plain; charset=utf-8",
          "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          "Accept": "application/json",
        })
        ..body = jsonEncode(updatedData);

      final response = await client.send(request);
      final streamedResponse = await http.Response.fromStream(response);

      if (streamedResponse.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Employee updated successfully ✅")),
        );
        Navigator.pop(context, updatedData);

        client.close();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Update failed ❌ ${streamedResponse.body}")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    const maritalStatusOptions = ["Single", "Married", "Other"];
    final orderedKeys = widget.employee.keys.toList();

    return Scaffold(
      appBar: AppBar(title: const Text("Edit Employee")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              for (var key in orderedKeys)
                if (key == "rowIndex")
                  const SizedBox.shrink()
                else if (key == "Marital Status")
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: DropdownButtonFormField<String>(
                          value: maritalStatus,
                          decoration: const InputDecoration(
                            labelText: "Marital Status",
                            border: OutlineInputBorder(),
                          ),
                          items: maritalStatusOptions
                              .map(
                                (status) => DropdownMenuItem(
                                  value: status,
                                  child: Text(status),
                                ),
                              )
                              .toList(),
                          onChanged: (String? newValue) {
                            if (newValue != null) {
                              setState(() {
                                maritalStatus = newValue;
                                if (maritalStatus != "Married") {
                                  controllers["Spouse Name"]?.clear();
                                }
                              });
                            }
                          },
                          validator: (val) => val == null || val.isEmpty
                              ? "Select Marital Status"
                              : null,
                        ),
                      ),

                      if (maritalStatus == "Married")
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: TextFormField(
                            controller: controllers["Spouse Name"],
                            decoration: const InputDecoration(
                              labelText: "Spouse Name",
                              border: OutlineInputBorder(),
                            ),
                            validator: (val) => val == null || val.isEmpty
                                ? "Enter Spouse Name"
                                : null,
                          ),
                        ),
                    ],
                  )
                else if (key == "Spouse Name")
                  const SizedBox.shrink()
                else if (controllers.containsKey(key))
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: TextFormField(
                      controller: controllers[key]!,
                      decoration: InputDecoration(
                        labelText: key,
                        border: const OutlineInputBorder(),
                      ),
                      validator: (val) =>
                          val == null || val.isEmpty ? "Enter $key" : null,
                    ),
                  ),

              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.save),
                label: const Text("Update to Google Sheet"),
                onPressed: updateEmployee,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
