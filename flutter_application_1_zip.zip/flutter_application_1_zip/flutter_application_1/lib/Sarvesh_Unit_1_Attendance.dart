import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'dart:html' as html;
import 'main.dart'; // ✅ Import your login page

class AttendanceData {
  final String name;
  final String employeeId;
  final String status;
  final String shift;
  final DateTime date;

  AttendanceData({
    required this.name,
    required this.employeeId,
    required this.status,
    required this.shift,
    required this.date,
  });

  factory AttendanceData.fromJson(Map<String, dynamic> json) {
    return AttendanceData(
      name: json['Name']?.toString() ?? '', // Convert to String, handle null
      employeeId: json['Employee ID']?.toString() ?? '', // Convert to String
      status: json['Status']?.toString() ?? '',
      shift: json['Shift']?.toString() ?? '',
      date:
          DateTime.tryParse(json['Date']?.toString() ?? '') ??
          DateTime.now(), // Fallback to now if parsing fails
    );
  }
}

class SarveshUnit1AttendancePage extends StatefulWidget {
  const SarveshUnit1AttendancePage({super.key});

  @override
  State<SarveshUnit1AttendancePage> createState() =>
      _SarveshUnit1AttendancePageState();
}

class _SarveshUnit1AttendancePageState
    extends State<SarveshUnit1AttendancePage> {
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final idController = TextEditingController();

  String attendanceStatus = "Present";
  String shiftType = "Full Day";

  final String sheetUrl =
      "https://script.google.com/macros/s/AKfycbxbehmVtX_FA6RynPtYs3IC36mf1QbitHSGpSIAmT3NKCcuQSzJOlnN8nlHSfu2BVdH/exec";

  Future<void> saveToSheet() async {
    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all required fields ❗")),
      );
      return;
    }

    final data = {
      "Name": nameController.text.trim(),
      "Employee ID": idController.text.trim(),
      "Status": attendanceStatus,
      "Shift": attendanceStatus == "Present" ? shiftType : "N/A",
      "Date": DateTime.now().toIso8601String().split("T").first,
    };

    try {
      var client = http.Client();
      final request = http.Request('POST', Uri.parse(sheetUrl))
        ..headers.addAll({
          "Content-Type": "text/plain; charset=utf-8",
          "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          "Accept": "application/json",
        })
        ..body = jsonEncode(data);

      final response = await client.send(request);
      final streamedResponse = await http.Response.fromStream(response);

      if (streamedResponse.statusCode == 200) {
        final result = jsonDecode(streamedResponse.body);
        if (result["status"] == "success") {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("✅ Attendance saved successfully")),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text("❌ Error: ${result["message"] ?? "Unknown error"}"),
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "❌ Failed (${streamedResponse.statusCode}): ${streamedResponse.body}",
            ),
          ),
        );
      }
      client.close();
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("❌ Network error: $e")));
    }
  }

  Future<Uint8List> _generatePdf(List<AttendanceData> data) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return [
            pw.Header(
              level: 0,
              child: pw.Text(
                'Employee Attendance Report',
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
            pw.TableHelper.fromTextArray(
              headers: ['Name', 'Employee ID', 'Status', 'Shift', 'Date'],
              data: data.map((item) {
                return [
                  item.name,
                  item.employeeId,
                  item.status,
                  item.shift,
                  '${item.date.toLocal()}'.split(' ')[0], // Format date
                ];
              }).toList(),
              cellAlignment: pw.Alignment.centerLeft,
              headerAlignment: pw.Alignment.centerLeft,
            ),
          ];
        },
      ),
    );

    return pdf.save();
  }

  Future<void> downloadPDF() async {
    try {
      var client = http.Client();
      final request = http.Request('GET', Uri.parse(sheetUrl));
      final response = await client.send(request);
      final streamedResponse = await http.Response.fromStream(response);

      if (streamedResponse.statusCode == 200) {
        final dynamic jsonData = jsonDecode(streamedResponse.body);
        final List<AttendanceData> attendanceList = (jsonData is List)
            ? jsonData.map((json) => AttendanceData.fromJson(json)).toList()
            : [];

        // Generate the PDF
        final pdfBytes = await _generatePdf(attendanceList);

        // Create a Blob from the PDF bytes
        final blob = html.Blob([pdfBytes], 'application/pdf');

        // Trigger the download
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.document.createElement('a') as html.AnchorElement
          ..href = url
          ..style.display = 'none'
          ..download = 'attendance_report.pdf';

        html.document.body?.children.add(anchor);
        anchor.click();
        html.document.body?.children.remove(anchor);
        html.Url.revokeObjectUrl(url);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("✅ PDF downloaded successfully")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "❌ Failed (${streamedResponse.statusCode}): ${streamedResponse.body}",
            ),
          ),
        );
      }
      client.close();
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("❌ Network error: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Attendance - Sarvesh Unit 1"),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Image.asset(
              'assets/logo.png',
              height: 30,
              width: 30,
              errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.image_not_supported),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
            onPressed: () {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text("Logged out")));
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              buildCard(
                icon: Icons.person,
                title: "Employee Details",
                child: Column(
                  children: [
                    buildTextField("Name", nameController),
                    const SizedBox(height: 10),
                    buildTextField("Employee ID", idController),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              buildCard(
                icon: Icons.check_circle,
                title: "Attendance Status",
                child: buildSegmentedControl(
                  ["Present", "Absent"],
                  attendanceStatus,
                  (val) => setState(() => attendanceStatus = val),
                ),
              ),
              const SizedBox(height: 16),
              if (attendanceStatus == "Present")
                buildCard(
                  icon: Icons.access_time,
                  title: "Shift Type",
                  child: buildSegmentedControl(
                    ["Full Day", "Half Day", "Kal Shift"],
                    shiftType,
                    (val) => setState(() => shiftType = val),
                  ),
                ),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.cloud_upload),
                    label: const Text("Save to Sheet"),
                    onPressed: saveToSheet,
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text("Download PDF"),
                    onPressed: downloadPDF,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildCard({
    required IconData icon,
    required String title,
    required Widget child,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.blue),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }

  Widget buildTextField(String label, TextEditingController controller) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      validator: (val) => val == null || val.isEmpty ? "Enter $label" : null,
    );
  }

  Widget buildSegmentedControl(
    List<String> options,
    String selected,
    void Function(String) onChanged,
  ) {
    return Wrap(
      spacing: 10,
      children: options.map((option) {
        final isSelected = option == selected;
        return ChoiceChip(
          label: Text(option),
          selected: isSelected,
          onSelected: (_) => onChanged(option),
          selectedColor: Colors.blue.shade100,
          labelStyle: TextStyle(
            color: isSelected ? Colors.blue.shade900 : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        );
      }).toList(),
    );
  }
}
